//
//  TaskModel.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 13/02/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import Foundation
class TaskModel{
    var name:String?
    var memo:String?
    
}
