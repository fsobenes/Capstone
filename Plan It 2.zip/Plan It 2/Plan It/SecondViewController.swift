//
//  SecondViewController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 1/23/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

//01/23/2020

import UIKit
import FSCalendar

class CalendarViewController: UIViewController, FSCalendarDelegate, FSCalendarDataSource, UITableViewDataSource, UITableViewDelegate, UIGestureRecognizerDelegate{
    
    let MAXIMUMEVENTSPERDAY = 6
    let MAXEVENTSINTENTION = 4
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    var eventDates:[String:Int] = [:]
    
    var eventInformation:[String:[TaskModel]]? = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        calendar.register(FSCalendarCell.self, forCellReuseIdentifier: "CELL")
        self.calendar.select(Date())
        calendar.delegate = self
        calendar.dataSource  = self
        
        
        //gesture for week view
        self.view.addGestureRecognizer(self.scopeGesture)
        self.tableView.panGestureRecognizer.require(toFail: self.scopeGesture)
        self.calendar.scope = .month
        
        
    }
    
    //MARK: trying week view
    fileprivate lazy var scopeGesture: UIPanGestureRecognizer = {
        [unowned self] in
        let panGesture = UIPanGestureRecognizer(target: self.calendar, action: #selector(self.calendar.handleScopeGesture(_:)))
        panGesture.delegate = self
        panGesture.minimumNumberOfTouches = 1
        panGesture.maximumNumberOfTouches = 2
        return panGesture
    }()
    
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        let shouldBegin = self.tableView.contentOffset.y <= -self.tableView.contentInset.top
        if shouldBegin {
            let velocity = self.scopeGesture.velocity(in: self.view)
            switch self.calendar.scope {
            case .month:
                return velocity.y < 0
            case .week:
                return velocity.y > 0
            @unknown default:
                Error.self
            }
        }
        return shouldBegin
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
        self.calendarHeightConstraint.constant = bounds.height
        self.view.layoutIfNeeded()
    }
    //end of week view
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let informationArray = eventInformation?[self.dateFormatter.string(from: calendar.selectedDate!)]
        return informationArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //        if indexPath.section == 0 {
        //            let identifier = ["cell_month", "cell_week"][indexPath.row]
        //            let cell = tableView.dequeueReusableCell(withIdentifier: identifier)!
        //            return cell
        //        } else {
        let cell:CalendarCell = tableView.dequeueReusableCell(withIdentifier: "cell")! as! CalendarCell
        
        let informationArray = eventInformation?[self.dateFormatter.string(from: calendar.selectedDate!)]
        
        let model = informationArray?[indexPath.row]
        
        cell.initalise(title:model?.name ?? "default", subtitleString:model?.memo  ?? "defailt")
        return cell
        //}
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
             let informationArray = eventInformation?[self.dateFormatter.string(from: calendar.selectedDate!)]
                   
            let model = informationArray?[indexPath.row]
           for (key, value) in eventInformation! {
                    var i = 0
                    for data in value{
                        if data.name == model!.name && data.memo == model!.memo!{
                            eventDates[key] = (eventDates[key] ?? 1) - 1
                            eventInformation?[key]?.remove(at: i)
                        break
                        }
                        i = i + 1;
                    }
            }
            self.loadViewIfNeeded()
            self.calendar.reloadData()
            self.tableView.reloadData()
        }
    }
    
    //MARK: delete row
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete{
//            eventDates.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .bottom)
//        }
//    }
//    
    
    
    @IBAction func barbuttonTapped(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "EventAddViewController") as! EventAddViewController
        nextViewController.date = calendar.selectedDate
        nextViewController.delegate = self
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}

class Tasks {
    var name = ""
    var checked = false
    
    convenience init(name: String){
        self.init()
        self.name = name
    }
}

extension CalendarViewController{
    
    // func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
    //    print("did select date \(self.dateFormatter.string(from: date))")
    //    let selectedDates = calendar.selectedDates.map({self.dateFormatter.string(from: $0)})
    //    print("selected dates is \(selectedDates)")
    //    if monthPosition == .next || monthPosition == .previous {
    //        calendar.setCurrentPage(date, animated: true)
    //    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("did select date \(self.dateFormatter.string(from: date))")
        let selectedDates = calendar.selectedDates.map({self.dateFormatter.string(from: $0)})
        print("selected dates is \(selectedDates)")
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        self.tableView.reloadData()
        
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventDefaultColorsFor date: Date) -> [UIColor]? {
        let dateString = self.dateFormatter.string(from: date)
        if (self.eventDates[dateString] != nil) {
            return [UIColor.white]
        }
        return [UIColor.white]
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        let dateString = self.dateFormatter.string(from: date)
        if (self.eventDates[dateString] != nil) {
            return eventDates[dateString] ?? 0
        }
        return 0 ;
    }
    
}

//coredata
extension CalendarViewController:EventAddViewControllerPrototocol{
   
    
    
    
    func saveButtonTapped(title: String, memo: String, date: Date,isFromIntention: Bool ) {
        let model = TaskModel()
        model.name = title
        model.memo  = memo
        if isFromIntention == false{
            if let eventCount = eventDates[self.dateFormatter.string(from: date)]{
                if (eventCount == MAXIMUMEVENTSPERDAY){
                    let alert = UIAlertController(title: "Slow Down!", message: "You are overloaded. Please try other Date.", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    return
                    
                }
                eventDates[self.dateFormatter.string(from: date)] = eventCount + 1
                eventInformation?[self.dateFormatter.string(from: date)]?.append(model)
            }else{
                eventDates[self.dateFormatter.string(from: date)] = 1
                eventInformation?[self.dateFormatter.string(from: date)] = [model]
            }
        }else{
            
            var dateToAdded = date
            
            while true{
                // it means this date has events
                if let eventCount = eventDates[self.dateFormatter.string(from: dateToAdded)]{
                   
                    if (eventCount == MAXEVENTSINTENTION){
                        // proceed to the next as current day is full
                        dateToAdded = Calendar.current.date(byAdding: .day, value: 1, to: dateToAdded) ?? Date()
                        continue
                    }else { //if (eventCount == 0)
                        eventDates[self.dateFormatter.string(from: dateToAdded)] = eventCount + 1
                        eventInformation?[self.dateFormatter.string(from: dateToAdded)]?.append(model)
                        break
                    }
                }else{
                    eventDates[self.dateFormatter.string(from: dateToAdded)] = 1

                    eventInformation?[self.dateFormatter.string(from: dateToAdded)] = [model]
                    break
                }
            }
        }
        
            self.loadViewIfNeeded()
            self.calendar.reloadData()
            self.tableView.reloadData()
        
    }
    
    func deleteButtonTapped(title: String, memo: String, date: Date,isFromIntention: Bool ) {
        for (key, value) in eventInformation! {
                var i = 0
                for data in value{
                if data.name == title && data.memo == memo{
                        eventDates[key] = (eventDates[key] ?? 1) - 1
                        eventInformation?[key]?.remove(at: i)
                    break
                    }
                    i = i + 1;
                }
        }
        self.loadViewIfNeeded()
        self.calendar.reloadData()
        self.tableView.reloadData()
    }
    
}
