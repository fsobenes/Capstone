//
//  IntentionsCell.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 2/5/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import UIKit

class IntentionsCell: UITableViewCell {

    @IBOutlet weak var taskNameLabel: UILabel!
    @IBOutlet weak var taskNameSubtitle: UILabel!
    

}
