//
//  EventAddViewController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 13/02/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import UIKit

protocol EventAddViewControllerPrototocol:class {
    func saveButtonTapped(title:String,memo:String,date:Date,isFromIntention:Bool)
}
class EventAddViewController: UIViewController {

    @IBOutlet weak var titleTF: UITextField!
    
    @IBOutlet weak var memoTF: UITextField!
    var date:Date?
    weak var delegate:EventAddViewControllerPrototocol?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func saveButtonTapped(_ sender: Any) {
        
        //add the event in the calender.
        self.delegate?.saveButtonTapped(title: self.titleTF.text!, memo:memoTF.text!,date:date!,isFromIntention: false)
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
