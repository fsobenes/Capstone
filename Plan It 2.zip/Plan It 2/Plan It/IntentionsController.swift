//
//  IntentionsController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 1/23/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import UIKit

class IntentionsController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddIntentionControllerProtocol {
    
    @IBOutlet weak var tableView: UITableView!
    
    var intention: [Intention] = []
    weak var delegate:EventAddViewControllerPrototocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        intention.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "IntentionsCell", for: indexPath) as! IntentionsCell
        
        cell.taskNameLabel.text = intention[indexPath.row].name
        cell.taskNameSubtitle.text = intention[indexPath.row].subtitle
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AddIntentionController
        vc.delegate = self
    }
    
    
    //MARK: delete cell


   //MARK: delete row
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            intention.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .bottom)
        }
    }
    
}
    


class Intention {
    var name = ""
    var subtitle = ""
    
    convenience init (name: String, subtitle: String){
        self.init()
        self.name = name
        self.subtitle = subtitle
    }
}

extension IntentionsController{
    func addIntention(name: String, subtitle: String) {
           intention.append(Intention(name: name, subtitle: subtitle))
        
        self.addToCalendarViewEvent(title: name, memo: subtitle, date: Date(), isFromIntention: true)
           tableView.reloadData()
          }
}

extension IntentionsController{
    
    func addToCalendarViewEvent(title: String, memo: String, date: Date, isFromIntention: Bool){
        guard let tabBarVC = UIApplication.shared.keyWindow?.rootViewController as? UITabBarController else { return }
        let calendarNavigationViewController = tabBarVC.viewControllers?[1] as! UINavigationController?
        let calendarController = calendarNavigationViewController?.viewControllers.first as! CalendarViewController
        calendarController.saveButtonTapped(title: title, memo: memo, date: Date(), isFromIntention: true)
        
    }
    
}
