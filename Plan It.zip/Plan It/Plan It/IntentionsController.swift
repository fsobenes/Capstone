//
//  IntentionsController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 1/23/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import UIKit

class IntentionsController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddIntention {
   
    
    @IBOutlet weak var tableView: UITableView!
    
    var intention: [Intention] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func addIntention(name: String, subtitle: String) {
        intention.append(Intention(name: name, subtitle: subtitle))
        tableView.reloadData() 
       }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        intention.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "IntentionsCell", for: indexPath) as! IntentionsCell
        
        cell.taskNameLabel.text = intention[indexPath.row].name
        cell.taskNameSubtitle.text = intention[indexPath.row].subtitle
        
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AddIntentionController
        vc.delegate = self
    }
}

class Intention {
    var name = ""
    var subtitle = ""
    
    convenience init (name: String, subtitle: String){
        self.init()
        self.name = name
        self.subtitle = subtitle
    }
}
