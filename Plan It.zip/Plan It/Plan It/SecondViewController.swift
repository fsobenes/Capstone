//
//  SecondViewController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 1/23/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

//01/23/2020

import UIKit
import FSCalendar

class SecondViewController: UIViewController, FSCalendarDelegate, FSCalendarDataSource, UITableViewDataSource, UITableViewDelegate{ //, UIGestureRecognizerDelegate {
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    var eventDates:[String:Int] = [:]
    
    var eventInformation:[String:[TaskModel]]? = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        calendar.register(FSCalendarCell.self, forCellReuseIdentifier: "CELL")
        self.calendar.select(Date())
        calendar.delegate = self
        calendar.dataSource  = self
        
        //        self.calendar.select(Date())
        //
        //        self.calendar.accessibilityIdentifier = "calendar"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let informationArray = eventInformation?[self.dateFormatter.string(from: calendar.selectedDate!)]
        return informationArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //        if indexPath.section == 0 {
        //            let identifier = ["cell_month", "cell_week"][indexPath.row]
        //            let cell = tableView.dequeueReusableCell(withIdentifier: identifier)!
        //            return cell
        //        } else {
        let cell:CalendarCell = tableView.dequeueReusableCell(withIdentifier: "cell")! as! CalendarCell
        
        let informationArray = eventInformation?[self.dateFormatter.string(from: calendar.selectedDate!)]
        
        let model = informationArray?[indexPath.row]
        
        cell.initalise(title:model?.name ?? "default", subtitleString:model?.memo  ?? "defailt")
        return cell
        //}
    }
    
    
    @IBAction func barbuttonTapped(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "EventAddViewController") as! EventAddViewController
        nextViewController.date = calendar.selectedDate
        nextViewController.delegate = self
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}

class Tasks {
    var name = ""
    var checked = false
    
    convenience init(name: String){
        self.init()
        self.name = name
    }
}

extension SecondViewController{
    
    // func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
    //    print("did select date \(self.dateFormatter.string(from: date))")
    //    let selectedDates = calendar.selectedDates.map({self.dateFormatter.string(from: $0)})
    //    print("selected dates is \(selectedDates)")
    //    if monthPosition == .next || monthPosition == .previous {
    //        calendar.setCurrentPage(date, animated: true)
    //    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("did select date \(self.dateFormatter.string(from: date))")
        let selectedDates = calendar.selectedDates.map({self.dateFormatter.string(from: $0)})
        print("selected dates is \(selectedDates)")
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        self.tableView.reloadData()
        
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventDefaultColorsFor date: Date) -> [UIColor]? {
        let dateString = self.dateFormatter.string(from: date)
        if (self.eventDates[dateString] != nil) {
            return [UIColor.white]
        }
        return [UIColor.red]
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        let dateString = self.dateFormatter.string(from: date)
        if (self.eventDates[dateString] != nil) {
            return eventDates[dateString] ?? 0
        }
        return 0 ;
    }
}

//coredata
extension SecondViewController:EventAddViewControllerPrototocol{
    func saveButtonTapped(title: String, memo: String, date: Date) {
        let model = TaskModel()
        model.name = title
        model.memo  = memo
         if let eventCount = eventDates[self.dateFormatter.string(from: date)]{
            eventDates[self.dateFormatter.string(from: date)] = eventCount + 1
            eventInformation?[self.dateFormatter.string(from: date)]?.append(model)
        }else{
            eventDates[self.dateFormatter.string(from: date)] = 1

            eventInformation?[self.dateFormatter.string(from: date)] = [model]
        }
        self.calendar.reloadData()
        self.tableView.reloadData()
    }
}
