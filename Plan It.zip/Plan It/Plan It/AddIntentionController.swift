//
//  AddIntentionController.swift
//  Plan It
//
//  Created by Fiorella Sobenes on 2/18/20.
//  Copyright © 2020 Fiorella Sobenes. All rights reserved.
//

import UIKit

protocol AddIntention {
    func addIntention(name: String, subtitle: String)
}

class AddIntentionController: UIViewController {

    var delegate: AddIntention?
    
    @IBOutlet weak var taskName: UITextField!
    @IBOutlet weak var taskSubtitle: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func saveIntention(_ sender: Any) {
        
        if taskName.text != ""{
            delegate?.addIntention(name: taskName.text!, subtitle: taskSubtitle.text!)
            navigationController?.popViewController(animated: true)
        }
    }
}
